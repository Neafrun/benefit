import React from 'react';

const Page2 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Page 2</h1>
      <p>Page 2 내용입니다.</p>
    </div>
  );
};

export default Page2;
