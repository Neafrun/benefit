import React from 'react';

const Page1 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>진영</h1>
      <p>Page 1 내용입니다.</p>
    </div>
  );
};

export default Page1;
