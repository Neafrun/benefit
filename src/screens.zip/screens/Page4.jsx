import React from 'react';

const Page4 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Page 4</h1>
      <p>이지훈 페이지입니닷 1129.</p>
    </div>
  );
};

export default Page4;
