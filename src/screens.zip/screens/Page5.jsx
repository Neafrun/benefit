import React from 'react';

const Page5 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Page 5</h1>
      <p>Page 5 내용입니다.</p>
    </div>
  );
};

export default Page5;
