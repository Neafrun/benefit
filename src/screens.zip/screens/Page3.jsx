import React from 'react';

const Page3 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Page 3</h1>
      <p>Page 3 내용입니다.</p>
    </div>
  );
};

export default Page3;
