import React from 'react';

const Page6 = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>Page 6</h1>
      <p>Page 6 내용입니다.</p>
    </div>
  );
};

export default Page6;
